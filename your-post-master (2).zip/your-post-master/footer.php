</div>

<footer class="main-footer">
    <div class="footer-left">
        <a href="#">Evsu App | POST what you feel.</a></a>
    </div>
    <div class="footer-right">
    </div>
</footer>
</div>
</div>
<!-- General JS Scripts -->
<script src="./assets/js/app.min.js"></script>


<script src="./assets/bundles/summernote/summernote-bs4.js"></script>
<!-- JS Libraies -->
<script src="./assets/bundles/datatables/datatables.min.js"></script>
<script src="./assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
<script src="./assets/bundles/upload-preview/assets/js/jquery.uploadPreview.min.js"></script>
<script src="./assets/bundles/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
<script src="./assets/bundles/jquery-ui/jquery-ui.min.js"></script>
<!-- Page Specific JS File -->
<script src="./assets/js/page/datatables.js"></script>
<script src="./assets/js/page/posts.js"></script>
<!-- JS Libraies -->
<!-- Page Specific JS File -->
<script src="./assets/js/page/create-post.js"></script>
<!-- Template JS File -->
<script src="./assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="./assets/js/custom.js"></script>
</body>

</html>