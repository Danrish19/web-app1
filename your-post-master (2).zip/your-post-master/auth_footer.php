</div>
</div>
<!-- General JS Scripts -->
<script src="./assets/js/app.min.js"></script>
<script src="./assets/bundles/jquery-ui/jquery-ui.min.js"></script>
<script src="./assets/bundles/jquery-pwstrength/jquery.pwstrength.min.js"></script>
<script src="./assets/bundles/jquery-selectric/jquery.selectric.min.js"></script>
<script src="./assets/bundles/izitoast/js/iziToast.min.js"></script>
<!-- JS Libraies -->
<script src="./assets/js/page/auth-register.js"></script>
<!-- Template JS File -->
<script src="./assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="./assets/js/custom.js"></script>
</body>

</html>