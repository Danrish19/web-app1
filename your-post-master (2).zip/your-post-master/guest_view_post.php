<?php
include_once './main_header.php';

$post = Post::findPostById($connection, $_GET['id']);

?>
<!DOCTYPE html>
<html lang="en">


<!-- errors-403.html  21 Nov 2019 04:05:02 GMT -->

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Otika - Admin Dashboard Template</title>
    <!-- General CSS Files -->
    <link rel="stylesheet" href="assets/css/app.min.css">
    <!-- Template CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/components.css">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
    <style>
        .navbar {
            left: 0 !important;
        }

        .main-content {
            padding-left: 0px;
        }
    </style>
</head>

<body>
    <div class="loader"></div>
    <div id="app">
        <div class="main-wrapper main-wrapper-1">
            <div class="navbar-bg"></div>
            <nav class="navbar navbar-expand-lg main-navbar sticky">
                <div class="container">
                    <a class="navbar-brand" href="#">Your Post</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav mr-auto">

                        </ul>

                        <a href="login.php" class="btn btn-outline-warning my-2 my-sm-0">Login</a>

                    </div>
                </div>

            </nav>
            <!-- Main Content -->
            <div class="main-content">
                <main class="container" style="width: 600px">
                    <div class="p-1 px-sm-1">

                        <div class="row">
                            <div class="col-12">
                                <div class="card mb-0">
                                    <div class="card-body">
                                        <a class="btn btn-link" href="./index.php">
                                        <i class="fa fa-arrow-left"></i>    
                                        Back</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-4">

                            <div class="col-12">
                                <div class="card card-primary">
                                    <div class="card-header">
                                        <h4><?php echo  $post->title; ?> <span style="font-size: 10px;" class="badge ml-2 badge-info"><?php echo $post->category; ?></span></h4>
                                    </div>
                                    <div class="card-body">
                                        <p class="text-muted">Author : <?php echo $post->author; ?> </p>
                                        <?php echo $post->body; ?>
                                    </div>
                                    <div class="card-footer">
                                        <?php echo "Created : " . date_format(date_create($post->created_at), "M d Y"); ?>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                </main>
            </div>
        </div>
    </div>
    <!-- General JS Scripts -->
    <script src="assets/js/app.min.js"></script>
    <!-- JS Libraies -->
    <!-- Page Specific JS File -->
    <!-- Template JS File -->
    <script src="assets/js/scripts.js"></script>
    <!-- Custom JS File -->
    <script src="assets/js/custom.js"></script>
</body>


<!-- errors-403.html  21 Nov 2019 04:05:02 GMT -->

</html>